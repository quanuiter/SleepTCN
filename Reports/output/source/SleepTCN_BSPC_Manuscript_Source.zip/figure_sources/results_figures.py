"""Write PGFPlots/TikZ sources for the results figures (English and Vietnamese).

Values are transcribed without recomputation from locked tables:
  confusion   -> Supplementary Tables tab:sup_edf_confusion and tab:sup_shhs_confusion
                 (E3, seed 42; rows normalised to percentages here)
  holdout     -> main Table tab:holdout-confirmatory, the first-sample Table tab:shhs-paired,
                 Supplementary Table tab:sup_shhs_secondary_paired (first-sample E3-E2) and
                 Supplementary Table tab:sup_holdout_s2 (between-seed differences, E4-E3)
  seeds       -> Supplementary Tables tab:sup_edf_seeds, tab:sup_holdout_arms and tab:sup_a2_arms
  amplitude   -> Supplementary Section S5 (tab:sup_amendment_arms), formerly main-text Table 9

Run from this folder: python results_figures.py
Then compile each written .tex with pdflatex (EN) or xelatex (VI) and keep the PDF beside the paper.
"""
from pathlib import Path

HERE = Path(__file__).resolve().parent
EN_OUT = HERE                                   # sources stay in figure_sources/
VI_OUT = HERE.parents[1] / 'paper_vi_translation' / 'figures'

STAGES = ['W', 'N1', 'N2', 'N3', 'REM']
EDF = [[61133, 3888, 416, 56, 448], [3283, 11643, 4867, 105, 1624], [539, 5496, 58394, 2271, 2432],
       [30, 45, 2377, 10558, 29], [483, 1542, 1984, 90, 21736]]
SHHS = [[29638, 4481, 1171, 21, 1672], [874, 3807, 601, 3, 1717], [2348, 5947, 56063, 324, 11605],
        [78, 39, 16674, 5888, 127], [655, 784, 1311, 1, 23183]]

# (estimate, low, high); H1 E3-E0, H2 E3-E6, H3 E3-E2
FIRST = [(0.0412, 0.0314, 0.0512), (0.0274, 0.0182, 0.0370), (0.0475, 0.0372, 0.0579)]
HOLD42 = [(0.0467, 0.0403, 0.0531), (0.0293, 0.0231, 0.0354), (0.0515, 0.0460, 0.0571)]
HOLD123 = [(0.0375, 0.0307, 0.0444), (0.0129, 0.0057, 0.0199), (0.0270, 0.0217, 0.0325)]
# between-seed differences (seed 42 minus seed 123) and E4-E3 at each seed; E2 has no interval
SEEDS = [('E3', 0.0046, 0.0026, 0.0067), ('E4', 0.0094, 0.0076, 0.0112),
         ('E0', -0.0046, -0.0063, -0.0029), ('E6', -0.0118, -0.0151, -0.0085),
         ('E2', -0.0199, None, None)]
E4E3 = [('42', 0.0139, 0.0126, 0.0153), ('123', 0.0091, 0.0074, 0.0108)]

# per-seed scores: (seed 42, seed 123, further seeds); Sleep-EDF pooled out-of-fold macro-F1 and holdout
# subject-mean macro-F1 of the ten-model ensemble. E1 was not evaluated on the holdout sample.
SEED_EDF = [(0.7754, 0.7755, []), (0.7802, 0.7776, []), (0.7835, 0.7828, []), (0.7904, 0.7883, []),
            (0.7891, 0.7887, [0.7888, 0.7903, 0.7854]), (0.7691, 0.7780, []), (0.7702, 0.7749, [])]
SEED_HOLD = [(0.5170, 0.5216, []), None, (0.5122, 0.5321, []), (0.5637, 0.5591, []),
             (0.5776, 0.5682, [0.5634, 0.5822, 0.5686]), (0.5344, 0.5462, []), (0.5412, 0.5452, [])]

# amplitude sweep of E4 seed 42 on the holdout sample: gains 0.5, 0.75, 1, 1.5, 2, then AdaBN
N3_RECALL = [0.0176, 0.1327, 0.2742, 0.3559, 0.2318, 0.2828]
N3_TO_N2 = [0.933, 0.842, 0.711, 0.600, 0.486, 0.548]
F1_N3 = [0.0343, 0.2294, 0.4184, 0.5043, 0.3614, 0.4313]
MF1 = [0.4627, 0.5256, 0.5776, 0.5765, 0.4502, 0.4570]
F1_W = [0.8202, 0.8272, 0.8297, 0.7960, 0.6720, 0.7125]
F1_REM = [0.6733, 0.7161, 0.7436, 0.7054, 0.4143, 0.4590]

TEXT = {
    'en': dict(
        preamble='\\usepackage[T1]{fontenc}\n\\usepackage{newtxtext,newtxmath}',
        reference='Reference stage', predicted='Predicted stage',
        edf='Sleep-EDF (out-of-fold, $n=78$)', shhs='First SHHS1 sample ($n=180$)',
        h=['H1: E3$-$E0', 'H2: E3$-$E6', 'H3: E3$-$E2'],
        first='First sample, seed 42', hold42='Holdout, seed 42', hold123='Holdout, seed 123',
        delta='$\\Delta$ subject-mean macro-F1', panel_a='(a) Confirmatory contrasts',
        panel_b='(b) Between-seed differences and E4$-$E3',
        seeds_a='(a) Sleep-EDF, out-of-fold', seeds_b='(b) SHHS1 holdout, ten-model ensemble',
        seeds_xa='Pooled macro-F1', seeds_xb='Subject-mean macro-F1', seed_other='Seeds 2025, 2027, 2029',
        seed_name='Seed {}',
        rows=['E0 (unfiltered)', 'E1 (unfiltered)', 'E2 (unfiltered)', 'E3 (band-pass, $\\div$100)',
              'E4 (band-pass)', 'E6 (record $z$-score)', 'E6R (rolling $z$-score)'],
        seedrow='{} seed 42$-$123', e4e3='E4$-$E3, seed {}',
        gain='Input gain', adabn='AdaBN', score='Score',
        n3recall='N3 recall', n3n2='N3$\\to$N2 rate', f1n3='F1 N3',
        mf1='Subject-mean macro-F1', f1w='F1 W', f1rem='F1 REM',
        amp_a='(a) N3 errors', amp_b='(b) Overall and other stages'),
    'vi': dict(
        preamble='\\usepackage[no-math]{fontspec}\\setmainfont{Times New Roman}',
        reference='Giai đoạn tham chiếu', predicted='Giai đoạn dự đoán',
        edf='Sleep-EDF (ngoài fold, $n=78$)', shhs='Mẫu SHHS1 thứ nhất ($n=180$)',
        h=['H1: E3$-$E0', 'H2: E3$-$E6', 'H3: E3$-$E2'],
        first='Mẫu thứ nhất, seed 42', hold42='Mẫu giữ lại, seed 42', hold123='Mẫu giữ lại, seed 123',
        delta='$\\Delta$ macro-F1 trung bình theo đối tượng', panel_a='(a) Các đối chiếu xác nhận',
        panel_b='(b) Chênh lệch giữa hai seed và E4$-$E3',
        seeds_a='(a) Sleep-EDF, ngoài fold', seeds_b='(b) Mẫu SHHS1 giữ lại, ensemble mười mô hình',
        seeds_xa='Macro-F1 gộp', seeds_xb='Macro-F1 trung bình theo đối tượng',
        seed_other='Seed 2025, 2027, 2029', seed_name='Seed {}',
        rows=['E0 (không lọc)', 'E1 (không lọc)', 'E2 (không lọc)', 'E3 (thông dải, $\\div$100)',
              'E4 (thông dải)', 'E6 ($z$-score bản ghi)', 'E6R ($z$-score trượt)'],
        seedrow='{} seed 42$-$123', e4e3='E4$-$E3, seed {}',
        gain='Hệ số nhân đầu vào', adabn='AdaBN', score='Giá trị',
        n3recall='Độ thu hồi N3', n3n2='Tỷ lệ N3$\\to$N2', f1n3='F1 N3',
        mf1='Macro-F1 theo đối tượng', f1w='F1 W', f1rem='F1 REM',
        amp_a='(a) Lỗi N3', amp_b='(b) Hiệu năng chung và các giai đoạn khác'),
}

COLORS = """\\definecolor{sone}{HTML}{2A78D6}
\\definecolor{stwo}{HTML}{EB6834}
\\definecolor{sthree}{HTML}{1BAF7A}
\\definecolor{ink}{HTML}{3A3A38}
\\definecolor{muted}{HTML}{6E6E69}
\\definecolor{gridc}{HTML}{E4E4DF}"""

# sequential blue ramp, light to dark (0% -> 100% of a reference row)
RAMP = ['F4F8FD', 'CDE2FB', '9EC5F4', '6DA7EC', '3987E5', '256ABF', '184F95', '104281']


def header(lang, comment):
    return (f'% {comment}\n% Generated by results_figures.py; values transcribed from locked tables.\n'
            '\\documentclass[tikz,border=4pt]{standalone}\n'
            f"{TEXT[lang]['preamble']}\n\\usepackage{{pgfplots}}\n\\pgfplotsset{{compat=1.18}}\n"
            f'\\usepgfplotslibrary{{groupplots}}\n\\usetikzlibrary{{calc}}\n{COLORS}\n\\begin{{document}}\n')


def ramp(percent):
    position = min(percent, 100) / 100 * (len(RAMP) - 1)
    low = int(position)
    high = min(low + 1, len(RAMP) - 1)
    t = position - low
    a, b = (tuple(int(c[i:i + 2], 16) for i in (0, 2, 4)) for c in (RAMP[low], RAMP[high]))
    return ''.join(f'{round(x + (y - x) * t):02X}' for x, y in zip(a, b))


def confusion(lang):
    s = TEXT[lang]
    cell = 0.92
    out = [header(lang, 'Row-normalised E3 confusion matrices, Sleep-EDF and first SHHS1 sample.'),
           '\\begin{tikzpicture}[font=\\small]']
    for panel, (title, matrix) in enumerate(((s['edf'], EDF), (s['shhs'], SHHS))):
        x0 = panel * 6.9
        out.append(f'\\node[anchor=south,font=\\small\\bfseries] at ({x0 + 2.5 * cell:.3f},{5 * cell + 0.55:.3f}) {{{title}}};')
        for i, row in enumerate(matrix):
            total = sum(row)
            y = (4 - i) * cell
            out.append(f'\\node[anchor=east] at ({x0 - 0.08:.3f},{y + cell / 2:.3f}) {{{STAGES[i]}}};')
            for j, count in enumerate(row):
                pct = 100 * count / total
                fill = ramp(pct)
                text = 'white' if pct >= 45 else 'ink'
                x = x0 + j * cell
                out.append(f'\\definecolor{{c{panel}{i}{j}}}{{HTML}}{{{fill}}}')
                out.append(f'\\fill[c{panel}{i}{j}] ({x + 0.02:.3f},{y + 0.02:.3f}) rectangle ({x + cell - 0.02:.3f},{y + cell - 0.02:.3f});')
                out.append(f'\\node[text={text},font=\\footnotesize] at ({x + cell / 2:.3f},{y + cell / 2:.3f}) {{{pct:.1f}}};')
        # outline the N3 -> N2 cell, the dominant transfer error
        x, y = x0 + 2 * cell, 1 * cell
        out.append(f'\\draw[stwo,line width=1.4pt] ({x + 0.02:.3f},{y + 0.02:.3f}) rectangle ({x + cell - 0.02:.3f},{y + cell - 0.02:.3f});')
        for j, stage in enumerate(STAGES):
            out.append(f'\\node[anchor=north] at ({x0 + (j + 0.5) * cell:.3f},-0.05) {{{stage}}};')
        out.append(f'\\node[anchor=north] at ({x0 + 2.5 * cell:.3f},-0.5) {{{s["predicted"]}}};')
        out.append(f'\\node[rotate=90,anchor=south] at ({x0 - 0.62:.3f},{2.5 * cell:.3f}) {{{s["reference"]}}};')
    out += ['\\end{tikzpicture}', '\\end{document}', '']
    return '\n'.join(out)


def interval_plot(color, mark, points, size='2.6pt', fill=True):
    style = f'{color},mark={mark},mark size={size},line width=0.9pt'
    if not fill:
        style += ',mark options={fill=white}'
    coords = ' '.join(f'({est},{y}) +- ({est - lo},{0})' if lo is None else
                      f'({est},{y}) -= ({est - lo},0) += ({hi - est},0)' for est, lo, hi, y in points)
    return (f'\\addplot[{style},only marks,error bars/.cd,x dir=both,x explicit,'
            f'error bar style={{line width=0.9pt}},error mark options={{rotate=90,mark size=2pt}}] '
            f'coordinates {{{coords}}};')


def holdout(lang):
    s = TEXT[lang]
    common = ('xmin=-0.025,xmax=0.062,grid=major,major grid style={gridc},axis line style={muted},'
              'tick label style={font=\\footnotesize},label style={font=\\small},'
              'title style={font=\\small\\bfseries},xtick={-0.02,0,0.02,0.04,0.06},'
              'x tick label style={/pgf/number format/fixed,/pgf/number format/precision=2},'
              'scaled x ticks=false,'
              'ytick style={draw=none}')
    out = [header(lang, 'Holdout confirmation forest plot with between-seed differences.'),
           '\\begin{tikzpicture}', '\\begin{groupplot}[group style={group size=1 by 2,vertical sep=1.25cm},'
           'width=13.2cm,scale only axis,' + common + ']']
    # panel a: three hypotheses, three estimates each
    labels = ','.join('{' + h + '}' for h in s['h'])
    out.append(f'\\nextgroupplot[title={{{s["panel_a"]}}},height=3.4cm,ymin=0.4,ymax=3.6,ytick={{3,2,1}},'
               f'yticklabels={{{labels}}},y dir=normal,legend style={{font=\\footnotesize,draw=none,fill=white,'
               'fill opacity=0.85,text opacity=1,at={(0.01,0.97)},anchor=north west,legend columns=1},'
               'legend cell align=left]')
    out.append('\\addplot[ink,line width=0.7pt,forget plot] coordinates {(0,0.4) (0,3.6)};')
    for (rows, color, mark, offset, name) in ((FIRST, 'muted', '*', 0.25, s['first']),
                                              (HOLD42, 'sone', 'square*', 0.0, s['hold42']),
                                              (HOLD123, 'stwo', 'diamond*', -0.25, s['hold123'])):
        points = [(e, lo, hi, 3 - k + offset) for k, (e, lo, hi) in enumerate(rows)]
        out.append(interval_plot(color, mark, points, '2.8pt' if mark == 'diamond*' else '2.4pt'))
        out.append(f'\\addlegendentry{{{{{name}}}}}')
    # panel b: between-seed differences and E4-E3
    rows = [(s['seedrow'].format(name), e, lo, hi) for name, e, lo, hi in SEEDS]
    rows += [(s['e4e3'].format(seed), e, lo, hi) for seed, e, lo, hi in E4E3]
    n = len(rows)
    ticks = ','.join(str(n - k) for k in range(n))
    tick_labels = ','.join('{' + r[0] + '}' for r in rows)
    out.append(f'\\nextgroupplot[title={{{s["panel_b"]}}},height=4.1cm,ymin=0.4,ymax={n + 0.6},'
               f'ytick={{{ticks}}},yticklabels={{{tick_labels}}},xlabel={{{s["delta"]}}}]')
    out.append(f'\\addplot[ink,line width=0.7pt,forget plot] coordinates {{(0,0.4) (0,{n + 0.6})}};')
    seed_points = [(e, lo, hi, n - k) for k, (_, e, lo, hi) in enumerate(rows[:4])]
    out.append(interval_plot('ink', '*', seed_points, '2.2pt'))
    out.append(f'\\addplot[ink,only marks,mark=o,mark size=2.4pt,line width=0.9pt] coordinates {{({rows[4][1]},{n - 4})}};')
    e4_points = [(e, lo, hi, n - 5 - k) for k, (_, e, lo, hi) in enumerate(rows[5:])]
    out.append(interval_plot('sthree', 'triangle*', e4_points, '2.8pt'))
    out += ['\\end{groupplot}', '\\end{tikzpicture}', '\\end{document}', '']
    return '\n'.join(out)


def amplitude(lang):
    s = TEXT[lang]
    xs = [1, 2, 3, 4, 5]
    common = ('width=6.9cm,height=5.6cm,scale only axis=false,ymin=0,ymax=1,xmin=0.5,xmax=7.0,'
              'xtick={1,2,3,4,5,6.5},xticklabels={$\\times$0.5,$\\times$0.75,$\\times$1,$\\times$1.5,$\\times$2,'
              + s['adabn'] + '},grid=major,major grid style={gridc},axis line style={muted},'
              'tick label style={font=\\footnotesize},label style={font=\\small},'
              'title style={font=\\small\\bfseries},'
              'legend style={font=\\footnotesize,draw=none,fill=white,fill opacity=0.85,text opacity=1},'
              'legend cell align=left')
    out = [header(lang, 'Amplitude sweep and AdaBN for E4 (seed 42) on the SHHS1 holdout sample.'),
           '\\begin{tikzpicture}', '\\begin{groupplot}[group style={group size=2 by 1,horizontal sep=1.3cm},'
           + common + f',xlabel={{{s["gain"]}}}]']

    def series(values, color, mark, name):
        line = ' '.join(f'({x},{v})' for x, v in zip(xs, values[:5]))
        return [f'\\addplot[{color},mark={mark},mark size=2.6pt,line width=1.2pt] coordinates {{{line}}};',
                f'\\addlegendentry{{{{{name}}}}}',
                f'\\addplot[{color},only marks,mark={mark},mark size=2.6pt,forget plot] coordinates {{(6.5,{values[5]})}};']

    separator = '\\draw[muted,dashed] (axis cs:5.75,0) -- (axis cs:5.75,1);'
    reference = '\\draw[muted,dotted,line width=0.8pt] (axis cs:3,0) -- (axis cs:3,1);'
    out.append(f'\\nextgroupplot[title={{{s["amp_a"]}}},ylabel={{{s["score"]}}},'
               'legend style={at={(0.5,-0.24)},anchor=north,legend columns=1}]')
    out += series(N3_TO_N2, 'stwo', 'square*', s['n3n2'])
    out += series(N3_RECALL, 'sone', '*', s['n3recall'])
    out += series(F1_N3, 'sthree', 'triangle*', s['f1n3'])
    out += [separator, reference]
    out.append(f'\\nextgroupplot[title={{{s["amp_b"]}}},legend style={{at={{(0.5,-0.24)}},anchor=north,legend columns=1}}]')
    out += series(F1_W, 'stwo', 'square*', s['f1w'])
    out += series(F1_REM, 'sone', '*', s['f1rem'])
    out += series(MF1, 'sthree', 'triangle*', s['mf1'])
    out += [separator, reference, '\\end{groupplot}', '\\end{tikzpicture}', '\\end{document}', '']
    return '\n'.join(out)


def seeds(lang):
    s = TEXT[lang]
    n = len(s['rows'])
    ticks = ','.join(str(n - k) for k in range(n))
    labels = ','.join('{' + r + '}' for r in s['rows'])
    common = (f'width=5.6cm,height=5.0cm,scale only axis,ymin=0.4,ymax={n + 0.6},ytick={{{ticks}}},'
              f'yticklabels={{{labels}}},grid=major,major grid style={{gridc}},axis line style={{muted}},'
              'tick label style={font=\\footnotesize},label style={font=\\small},'
              'title style={font=\\small\\bfseries},ytick style={draw=none},scaled x ticks=false,'
              'x tick label style={/pgf/number format/fixed,/pgf/number format/precision=2,'
              '/pgf/number format/fixed zerofill},'
              'legend style={font=\\footnotesize,draw=none,legend columns=3,/tikz/every even column/.append '
              'style={column sep=0.35cm}},legend cell align=left')
    out = [header(lang, 'Per-seed scores of every configuration on Sleep-EDF and the SHHS1 holdout sample.'),
           '\\begin{tikzpicture}', '\\begin{groupplot}[group style={group size=2 by 1,horizontal sep=0.5cm,'
           'yticklabels at=edge left},' + common + ']']

    def panel(rows):
        lines = []
        for index, (color, mark, size, extra) in enumerate((('sone', '*', '2.6pt', ''),
                                                           ('stwo', 'square*', '2.4pt', ''),
                                                           ('ink', 'diamond', '2.8pt', ',line width=0.8pt'))):
            coords = []
            for k, row in enumerate(rows):
                if row is None:
                    continue
                values = row[2] if index == 2 else [row[index]]
                coords += [f'({v},{n - k})' for v in values]
            lines.append(f'\\addplot[{color},only marks,mark={mark},mark size={size}{extra}] coordinates '
                         f'{{{" ".join(coords)}}};')
        return lines

    out.append(f'\\nextgroupplot[title={{{s["seeds_a"]}}},xlabel={{{s["seeds_xa"]}}},xmin=0.715,xmax=0.805,'
               'xtick={0.72,0.74,0.76,0.78,0.80},legend to name=seedlegend]')
    out += panel(SEED_EDF)
    out += [f'\\addlegendentry{{{s["seed_name"].format(42)}}}',
            f'\\addlegendentry{{{s["seed_name"].format(123)}}}',
            f'\\addlegendentry{{{s["seed_other"]}}}']
    out.append(f'\\nextgroupplot[title={{{s["seeds_b"]}}},xlabel={{{s["seeds_xb"]}}},xmin=0.505,xmax=0.595,'
               'xtick={0.52,0.54,0.56,0.58}]')
    out += panel(SEED_HOLD)
    out += ['\\end{groupplot}',
            '\\node[anchor=north] at ($(group c1r1.south west)!0.5!(group c2r1.south east)+(0,-1.05cm)$) '
            '{\\pgfplotslegendfromname{seedlegend}};',
            '\\end{tikzpicture}', '\\end{document}', '']
    return '\n'.join(out)


def main():
    for lang, folder, suffix in (('en', EN_OUT, '_en'), ('vi', VI_OUT, '_vi')):
        for name, build in (('confusion', confusion), ('holdout', holdout), ('amplitude', amplitude), ('seeds', seeds)):
            (folder / f'{name}{suffix}.tex').write_text(build(lang), encoding='utf8')


if __name__ == '__main__':
    main()
